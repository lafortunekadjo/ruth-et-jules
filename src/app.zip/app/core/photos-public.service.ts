import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PhotoItem } from './models/admin.models';

@Injectable({ providedIn: 'root' })
export class PhotosPublicService {
  constructor(private http: HttpClient) {}

  lister(slug: string): Observable<PhotoItem[]> {
    return this.http.get<PhotoItem[]>(`/api/public/mariages/${slug}/photos`);
  }

  ajouter(slug: string, nomUploadeur: string, url: string): Observable<PhotoItem> {
    return this.http.post<PhotoItem>(`/api/public/mariages/${slug}/photos`, { nomUploadeur, url });
  }
}
