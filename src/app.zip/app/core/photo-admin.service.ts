import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PhotoItem } from './models/admin.models';

@Injectable({ providedIn: 'root' })
export class PhotoAdminService {
  constructor(private http: HttpClient) {}

  listerEnAttente(): Observable<PhotoItem[]> {
    return this.http.get<PhotoItem[]>('/api/admin/photos/en-attente');
  }

  approuver(id: string): Observable<void> {
    return this.http.post<void>(`/api/admin/photos/${id}/approuver`, {});
  }

  rejeter(id: string): Observable<void> {
    return this.http.delete<void>(`/api/admin/photos/${id}`);
  }
}
