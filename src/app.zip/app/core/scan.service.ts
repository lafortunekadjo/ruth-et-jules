import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ScanResultat {
  invite: string;
  nomConjoint: string;
  nbPlaces: number;
  nbEntreesScannees: number;
  epuise: boolean;
}

@Injectable({ providedIn: 'root' })
export class ScanService {
  constructor(private http: HttpClient) {}

  scanner(contenuQr: string): Observable<ScanResultat> {
    return this.http.post<ScanResultat>('/api/scan/entree', { contenuQr });
  }
}
