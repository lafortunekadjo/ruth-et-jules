import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WishlistItem } from './models/admin.models';

@Injectable({ providedIn: 'root' })
export class WishlistPublicService {
  constructor(private http: HttpClient) {}

  lister(slug: string): Observable<WishlistItem[]> {
    return this.http.get<WishlistItem[]>(`/api/public/mariages/${slug}/wishlist`);
  }

  reserver(slug: string, itemId: string, nomReservant: string): Observable<WishlistItem> {
    return this.http.post<WishlistItem>(`/api/public/mariages/${slug}/wishlist/${itemId}/reserver`, { nomReservant });
  }
}
