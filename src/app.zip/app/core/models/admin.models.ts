export type RoleUtilisateur = 'ADMIN' | 'CO_ORGANISATEUR' | 'STAFF_SCAN';
export type TypePlace = 'SOLO' | 'COUPLE';
export type StatutRsvp = 'EN_ATTENTE' | 'CONFIRME_SOLO' | 'CONFIRME_COUPLE' | 'DECLINE';

export interface InviteAdmin {
  id: string;
  nom: string;
  prenom: string;
  email: string | null;
  telephone: string | null;
  typePlace: TypePlace;
  statutRsvp: StatutRsvp;
  nomConjoint: string | null;
  tableId: string | null;
  tableNom: string | null;
}

export interface CreerInviteRequest {
  nom: string;
  prenom: string;
  email?: string;
  telephone?: string;
  typePlace: TypePlace;
}

export interface TableItem {
  id: string;
  nom: string;
  capacite: number;
}

export interface WishlistItem {
  id: string;
  nom: string;
  description: string | null;
  prix: number | null;
  lien: string | null;
  imageUrl: string | null;
  reserve: boolean;
}

export interface WishlistItemAdmin {
  id: string;
  nom: string;
  description: string | null;
  prix: number | null;
  lien: string | null;
  imageUrl: string | null;
  /** null = disponible ; sinon nom de l'invité ayant réservé. */
  reservePar: string | null;
}

export interface MessageLivreOr {
  id: string;
  auteur: string;
  message: string;
  approuve: boolean;
  dateCreation: string;
}

export interface PhotoItem {
  id: string;
  nomUploadeur: string | null;
  url: string;
  approuve: boolean;
  dateUpload: string;
}
