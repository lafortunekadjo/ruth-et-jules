import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MariagePublic, MariagePublicService } from '../../core/mariage-public.service';
import { WishlistPublicService } from '../../core/wishlist-public.service';
import { WishlistItem } from '../../core/models/admin.models';

@Component({
  selector: 'app-public-wishlist',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div
      class="scene"
      [style.--couleur-primaire]="couleur('couleurPrimaire', '#a88b4a')"
      [style.--couleur-fond]="couleur('couleurFond', '#fffdfa')"
      [style.--couleur-texte]="couleur('couleurTexte', '#2a2724')"
      [style.font-family]="mariage?.police ? mariage!.police + ', var(--police-affichage)' : 'var(--police-affichage)'"
    >
      <a class="retour" [routerLink]="['/m', slug]">← Retour</a>

      <p class="monogramme" *ngIf="mariage">{{ mariage.nomsCouple }}</p>
      <h1>Liste de mariage</h1>
      <p class="intro">Votre présence est le plus beau des cadeaux. Si vous souhaitez nous gâter, voici quelques idées.</p>

      <div class="grille">
        @for (item of items(); track item.id) {
          <div class="carte" [class.reserve]="item.reserve">
            @if (item.imageUrl) {
              <img [src]="item.imageUrl" alt="" />
            }
            <div class="contenu">
              <p class="nom">{{ item.nom }}</p>
              @if (item.prix) {
                <p class="prix">{{ item.prix }} €</p>
              }
              @if (item.description) {
                <p class="description">{{ item.description }}</p>
              }

              @if (item.reserve) {
                <p class="statut">Déjà réservé — merci !</p>
              } @else if (itemEnReservation === item.id) {
                <div class="form-reservation">
                  <input class="champ" [(ngModel)]="nomReservant" placeholder="Votre nom" />
                  <button class="bouton" (click)="confirmerReservation(item.id)" [disabled]="!nomReservant">Confirmer</button>
                </div>
              } @else {
                <button class="bouton" (click)="itemEnReservation = item.id">Je m'en occupe</button>
              }

              @if (erreur === item.id) {
                <p class="erreur">Ce cadeau vient d'être réservé par quelqu'un d'autre.</p>
              }
            </div>
          </div>
        }
      </div>

      @if (items().length === 0) {
        <p class="vide">La liste sera bientôt disponible.</p>
      }
    </div>
  `,
  styles: [`
    .scene { min-height: 100vh; background: var(--couleur-fond); color: var(--couleur-texte); padding: 2rem 1.5rem 4rem; }
    .retour { font-family: var(--police-texte); font-size: 0.85rem; color: inherit; opacity: 0.6; text-decoration: none; }
    .monogramme { font-family: var(--police-affichage); font-style: italic; color: var(--couleur-primaire); text-align: center; margin: 1.5rem 0 0.25rem; }
    h1 { font-family: var(--police-affichage); text-align: center; font-size: 2rem; font-weight: 500; margin-bottom: 0.5rem; }
    .intro { text-align: center; max-width: 480px; margin: 0 auto 2.5rem; font-family: var(--police-texte); opacity: 0.75; }
    .vide { text-align: center; opacity: 0.6; font-style: italic; }

    .grille { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1.5rem; max-width: 900px; margin: 0 auto; }
    .carte { background: #fff; border: 1px solid color-mix(in srgb, var(--couleur-primaire) 20%, transparent); border-radius: 8px; overflow: hidden; }
    .carte.reserve { opacity: 0.6; }
    .carte img { width: 100%; height: 160px; object-fit: cover; }
    .contenu { padding: 1.1rem; font-family: var(--police-texte); }
    .nom { font-family: var(--police-affichage); font-size: 1.1rem; margin: 0 0 0.25rem; }
    .prix { font-weight: 600; color: var(--couleur-primaire); margin: 0 0 0.5rem; }
    .description { font-size: 0.85rem; opacity: 0.75; margin: 0 0 0.75rem; }
    .statut { font-size: 0.85rem; font-style: italic; opacity: 0.6; }

    .bouton {
      font-family: var(--police-texte); font-weight: 600; font-size: 0.85rem;
      color: #fff; background: var(--couleur-primaire); border: none;
      border-radius: 999px; padding: 0.55rem 1.2rem; cursor: pointer; width: 100%;
    }
    .bouton:disabled { opacity: 0.5; cursor: not-allowed; }

    .form-reservation { display: flex; flex-direction: column; gap: 0.5rem; }
    .champ { padding: 0.55rem 0.75rem; border: 1px solid #ddd; border-radius: 6px; font-family: var(--police-texte); }
    .erreur { color: #b3402f; font-size: 0.8rem; margin-top: 0.5rem; }
  `]
})
export class PublicWishlistComponent implements OnInit {
  slug = '';
  mariage: MariagePublic | null = null;
  items = signal<WishlistItem[]>([]);

  itemEnReservation: string | null = null;
  nomReservant = '';
  erreur: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private mariagePublicService: MariagePublicService,
    private wishlistPublicService: WishlistPublicService
  ) {}

  ngOnInit(): void {
    this.slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.mariagePublicService.consulter(this.slug).subscribe(m => this.mariage = m);
    this.charger();
  }

  charger(): void {
    this.wishlistPublicService.lister(this.slug).subscribe(items => this.items.set(items));
  }

  couleur(cle: keyof MariagePublic, defaut: string): string {
    const valeur = this.mariage?.[cle] as string | null | undefined;
    return valeur || defaut;
  }

  confirmerReservation(itemId: string): void {
    this.erreur = null;
    this.wishlistPublicService.reserver(this.slug, itemId, this.nomReservant).subscribe({
      next: () => {
        this.itemEnReservation = null;
        this.nomReservant = '';
        this.charger();
      },
      error: () => {
        this.erreur = itemId;
        this.charger();
      }
    });
  }
}
