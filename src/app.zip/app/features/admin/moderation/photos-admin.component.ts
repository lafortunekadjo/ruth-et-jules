import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PhotoAdminService } from '../../../core/photo-admin.service';
import { PhotoItem } from '../../../core/models/admin.models';

@Component({
  selector: 'app-photos-admin',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h1>Galerie — modération</h1>
    <p class="sous-titre">Les photos ci-dessous ne sont pas encore visibles publiquement.</p>

    @if (photos().length === 0) {
      <p class="vide">Aucune photo en attente. 🎉</p>
    }

    <div class="grille">
      @for (p of photos(); track p.id) {
        <div class="carte">
          <img [src]="p.url" alt="" />
          <p class="uploadeur" *ngIf="p.nomUploadeur">Envoyée par {{ p.nomUploadeur }}</p>
          <div class="actions">
            <button class="btn btn-plein" (click)="approuver(p.id)">Publier</button>
            <button class="btn btn-discret" (click)="rejeter(p.id)">Rejeter</button>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
  :host {
    display: block;
    --primary: #4f46e5;
    --surface: #ffffff;
    --background: #f8fafc;
    --border: #e2e8f0;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --success: #16a34a;
    --success-hover: #15803d;
    --success-bg: #dcfce7;
    --danger: #ef4444;
    --danger-bg: #fef2f2;
    --danger-border: #fecaca;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  }

  h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-main);
    letter-spacing: -0.025em;
    margin: 0;
  }

  .sous-titre {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin: 0.25rem 0 1.5rem;
  }

  /* État vide */
  .vide {
    color: var(--text-muted);
    background: var(--surface);
    border: 1px dashed var(--border);
    border-radius: var(--radius);
    padding: 3rem 1.5rem;
    text-align: center;
    font-size: 0.95rem;
    margin: 0;
  }

  /* Grille de modération photos */
  .grille {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
    gap: 1.25rem;
  }

  /* Carte Photo */
  .carte {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    box-shadow: var(--shadow-sm);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .carte:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  /* Image de la carte */
  .carte img {
    width: 100%;
    aspect-ratio: 4 / 3;
    object-fit: cover;
    display: block;
    background-color: var(--background);
    transition: transform 0.3s ease;
  }

  .carte:hover img {
    transform: scale(1.03);
  }

  /* Info expéditeur */
  .uploadeur {
    font-size: 0.8rem;
    font-weight: 500;
    color: var(--text-muted);
    padding: 0.75rem 0.875rem 0.25rem;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: flex;
    align-items: center;
    gap: 0.35rem;
  }

  .uploadeur::before {
    content: '';
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: var(--primary);
    flex-shrink: 0;
  }

  /* Actions */
  .actions {
    display: flex;
    gap: 0.5rem;
    padding: 0.875rem;
    margin-top: auto;
  }

  /* Boutons */
  .btn {
    flex: 1;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.5rem 0.75rem;
    font-size: 0.825rem;
    font-weight: 600;
    border-radius: var(--radius-sm);
    border: none;
    cursor: pointer;
    transition: all 0.15s ease;
  }

  .btn-plein {
    background-color: var(--success);
    color: #ffffff;
  }

  .btn-plein:hover {
    background-color: var(--success-hover);
    box-shadow: 0 2px 4px rgba(22, 163, 74, 0.2);
  }

  .btn-discret {
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
  }

  .btn-discret:hover {
    background-color: var(--danger-bg);
    color: var(--danger);
    border-color: var(--danger-border);
  }
`]
})
export class PhotosAdminComponent implements OnInit {
  photos = signal<PhotoItem[]>([]);

  constructor(private photoAdminService: PhotoAdminService) {}

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.photoAdminService.listerEnAttente().subscribe(p => this.photos.set(p));
  }

  approuver(id: string): void {
    this.photoAdminService.approuver(id).subscribe(() => this.charger());
  }

  rejeter(id: string): void {
    this.photoAdminService.rejeter(id).subscribe(() => this.charger());
  }
}
