import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LivreOrAdminService } from '../../../core/livre-or-admin.service';
import { MessageLivreOr } from '../../../core/models/admin.models';

@Component({
  selector: 'app-livre-or-admin',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h1>Livre d'or — modération</h1>
    <p class="sous-titre">Les messages ci-dessous ne sont pas encore visibles publiquement.</p>

    @if (messages().length === 0) {
      <p class="vide">Aucun message en attente. 🎉</p>
    }

    <ul class="liste">
      @for (m of messages(); track m.id) {
        <li class="carte">
          <p class="auteur">{{ m.auteur }}</p>
          <p class="message">{{ m.message }}</p>
          <div class="actions">
            <button class="btn btn-plein" (click)="approuver(m.id)">Publier</button>
            <button class="btn btn-discret" (click)="rejeter(m.id)">Rejeter</button>
          </div>
        </li>
      }
    </ul>
  `,
  styles: [`
  :host {
    display: block;
    --primary: #4f46e5;
    --surface: #ffffff;
    --background: #f8fafc;
    --border: #e2e8f0;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --success: #16a34a;
    --success-hover: #15803d;
    --success-bg: #dcfce7;
    --danger: #ef4444;
    --danger-bg: #fef2f2;
    --danger-border: #fecaca;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  }

  h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-main);
    letter-spacing: -0.025em;
    margin: 0;
  }

  .sous-titre {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin: 0.25rem 0 1.5rem;
  }

  /* État vide */
  .vide {
    color: var(--text-muted);
    background: var(--surface);
    border: 1px dashed var(--border);
    border-radius: var(--radius);
    padding: 3rem 1.5rem;
    text-align: center;
    font-size: 0.95rem;
    max-width: 600px;
    margin: 0;
  }

  /* Liste et Cartes */
  .liste {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    max-width: 600px;
  }

  .carte {
    background: var(--surface);
    border: 1px solid var(--border);
    border-left: 4px solid #6366f1;
    border-radius: var(--radius);
    padding: 1.25rem;
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    box-shadow: var(--shadow-sm);
    transition: transform 0.15s ease, box-shadow 0.15s ease;
  }

  .carte:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  .auteur {
    font-size: 1rem;
    font-weight: 700;
    color: var(--text-main);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .auteur::before {
    content: '';
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #6366f1;
  }

  .message {
    margin: 0;
    color: #334155;
    font-size: 0.925rem;
    line-height: 1.6;
    white-space: pre-line;
    background: #f8fafc;
    padding: 0.85rem 1rem;
    border-radius: var(--radius-sm);
    border: 1px solid #f1f5f9;
  }

  /* Zone d'actions */
  .actions {
    display: flex;
    gap: 0.6rem;
    margin-top: 0.25rem;
    justify-content: flex-end;
  }

  /* Boutons */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
    font-weight: 600;
    border-radius: var(--radius-sm);
    border: none;
    cursor: pointer;
    transition: all 0.15s ease;
  }

  .btn-plein {
    background-color: var(--success);
    color: #ffffff;
  }

  .btn-plein:hover {
    background-color: var(--success-hover);
    box-shadow: 0 2px 4px rgba(22, 163, 74, 0.2);
  }

  .btn-discret {
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
  }

  .btn-discret:hover {
    background-color: var(--danger-bg);
    color: var(--danger);
    border-color: var(--danger-border);
  }
`]
})
export class LivreOrAdminComponent implements OnInit {
  messages = signal<MessageLivreOr[]>([]);

  constructor(private livreOrAdminService: LivreOrAdminService) {}

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.livreOrAdminService.listerEnAttente().subscribe(m => this.messages.set(m));
  }

  approuver(id: string): void {
    this.livreOrAdminService.approuver(id).subscribe(() => this.charger());
  }

  rejeter(id: string): void {
    this.livreOrAdminService.rejeter(id).subscribe(() => this.charger());
  }
}
