import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CdkDragDrop, DragDropModule, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { TableAdminService } from '../../../core/table-admin.service';
import { InviteAdminService } from '../../../core/invite-admin.service';
import { InviteAdmin, TableItem } from '../../../core/models/admin.models';

interface TableAvecInvites extends TableItem {
  invites: InviteAdmin[];
}

@Component({
  selector: 'app-table-plan',
  standalone: true,
  imports: [CommonModule, FormsModule, DragDropModule],
  template: `
    <h1>Plan de table</h1>
    <p class="sous-titre">Glissez-déposez les invités entre les tables — la capacité est toujours vérifiée.</p>

    <form class="carte creation" (ngSubmit)="creerTable()">
      <input class="champ" name="nomTable" [(ngModel)]="nouvelleTable.nom" placeholder="Nom de la table" required />
      <input class="champ" name="capacite" [(ngModel)]="nouvelleTable.capacite" type="number" min="1" placeholder="Capacité" required />
      <button type="submit" class="btn btn-plein" [disabled]="enCours()">Ajouter une table</button>
    </form>

    @if (erreur()) {
      <p class="erreur-texte">{{ erreur() }}</p>
    }

    <div class="plan">
      <!-- Colonne des invités non affectés -->
      <div class="colonne non-affectes">
        <h2>Non affectés <span class="compte">{{ nonAffectes().length }}</span></h2>
        <div
          cdkDropList
          id="non-affectes"
          [cdkDropListData]="nonAffectes()"
          [cdkDropListConnectedTo]="idsListesTables()"
          class="zone-drop"
          (cdkDropListDropped)="onDrop($event, null)"
        >
          @for (invite of nonAffectes(); track invite.id) {
            <div class="carte-invite" cdkDrag>{{ invite.prenom }} {{ invite.nom }}</div>
          }
        </div>
      </div>

      <!-- Une colonne par table -->
      @for (table of tables(); track table.id) {
        <div class="colonne">
          <h2>
            {{ table.nom }}
           <span class="badge" 
              [class.badge-or]="table.invites.length >= table.capacite" 
              [class.badge-neutre]="table.invites.length < table.capacite">
              {{ table.invites.length }} / {{ table.capacite }}
            </span>
            <button class="supprimer-table" (click)="supprimerTable(table.id)" title="Supprimer la table">✕</button>
          </h2>
          <div
            cdkDropList
            [id]="'table-' + table.id"
            [cdkDropListData]="table.invites"
            [cdkDropListConnectedTo]="idsListesConnectees(table.id)"
            class="zone-drop"
            (cdkDropListDropped)="onDrop($event, table.id)"
          >
            @for (invite of table.invites; track invite.id) {
              <div class="carte-invite" cdkDrag>{{ invite.prenom }} {{ invite.nom }}</div>
            }
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
  :host {
    display: block;
    --primary: #4f46e5;
    --primary-hover: #4338ca;
    --surface: #ffffff;
    --background: #f8fafc;
    --border: #e2e8f0;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --danger: #ef4444;
    --danger-bg: #fef2f2;
    --danger-border: #fecaca;
    --success: #16a34a;
    --success-bg: #dcfce7;
    --warning: #d97706;
    --warning-bg: #fef3c7;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
    --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  }

  h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-main);
    letter-spacing: -0.025em;
    margin: 0;
  }

  .sous-titre {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin: 0.25rem 0 1.5rem;
  }

  /* Formulaire de création */
  .carte.creation {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1rem 1.25rem;
    display: flex;
    gap: 0.75rem;
    max-width: 460px;
    margin-bottom: 1.5rem;
    align-items: center;
    box-shadow: var(--shadow-sm);
  }

  .creation .champ {
    padding: 0.625rem 0.875rem;
    font-size: 0.875rem;
    color: var(--text-main);
    background-color: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
    box-sizing: border-box;
  }

  .creation .champ:focus-visible {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
  }

  .creation .champ:first-child { flex: 1; }
  .creation .champ:nth-child(2) { width: 110px; }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.625rem 1.25rem;
    font-size: 0.875rem;
    font-weight: 600;
    border-radius: var(--radius-sm);
    border: none;
    cursor: pointer;
    white-space: nowrap;
    transition: background-color 0.15s ease, opacity 0.15s ease;
  }

  .btn-plein {
    background-color: var(--primary);
    color: #ffffff;
  }

  .btn-plein:hover:not(:disabled) {
    background-color: var(--primary-hover);
  }

  .btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  /* Bannière d'erreur */
  .erreur-texte {
    background-color: var(--danger-bg);
    color: #991b1b;
    border: 1px solid var(--danger-border);
    padding: 0.75rem 1rem;
    border-radius: var(--radius-sm);
    font-size: 0.875rem;
    font-weight: 500;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  /* Plan Kanban / Horizontal */
  .plan {
    display: flex;
    gap: 1.25rem;
    overflow-x: auto;
    padding-bottom: 1rem;
    align-items: flex-start;
  }

  .plan::-webkit-scrollbar {
    height: 8px;
  }
  .plan::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }
  .plan::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  .plan::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }

  .colonne {
    width: 270px;
    min-width: 270px;
    flex: 0 0 auto;
    background: #f8fafc;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1rem;
    box-shadow: var(--shadow-sm);
    display: flex;
    flex-direction: column;
    max-height: calc(100vh - 250px);
  }

  .colonne.non-affectes {
    background: #ffffff;
    border-color: #cbd5e1;
  }

  .colonne h2 {
    font-size: 0.95rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin: 0 0 1rem;
    color: var(--text-main);
  }

  .compte {
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--text-muted);
    background: #e2e8f0;
    border-radius: 9999px;
    padding: 0.15rem 0.6rem;
  }

  /* Badges de capacité */
  .badge {
    font-size: 0.75rem;
    font-weight: 600;
    padding: 0.2rem 0.55rem;
    border-radius: 9999px;
    display: inline-flex;
    align-items: center;
  }

  .badge-neutre {
    background-color: #e2e8f0;
    color: #475569;
  }

  .badge-or {
    background-color: var(--warning-bg);
    color: var(--warning);
    border: 1px solid #fde68a;
  }

  .supprimer-table {
    margin-left: auto;
    background: transparent;
    border: none;
    border-radius: 6px;
    width: 26px;
    height: 26px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: #94a3b8;
    font-size: 0.85rem;
    transition: all 0.15s ease;
  }

  .supprimer-table:hover {
    background-color: var(--danger-bg);
    color: var(--danger);
  }

  /* Zone de Drop */
  .zone-drop {
    min-height: 120px;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    flex: 1;
    overflow-y: auto;
    padding: 0.25rem;
    border-radius: var(--radius-sm);
  }

  /* Cartes d'invités */
  .carte-invite {
    background: var(--surface);
    border: 1px solid var(--border);
    border-left: 3px solid var(--primary);
    border-radius: var(--radius-sm);
    padding: 0.65rem 0.85rem;
    cursor: grab;
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--text-main);
    box-shadow: var(--shadow-sm);
    user-select: none;
    transition: box-shadow 0.15s ease, border-color 0.15s ease, transform 0.15s ease;
  }

  .carte-invite:hover {
    box-shadow: var(--shadow-md);
    border-color: #cbd5e1;
    border-left-color: var(--primary-hover);
  }

  .carte-invite:active {
    cursor: grabbing;
  }

  /* Angular CDK Drag & Drop Styles */
  .cdk-drag-preview {
    box-sizing: border-box;
    border-radius: var(--radius-sm);
    box-shadow: var(--shadow-lg);
    border: 1px solid var(--primary);
    border-left: 4px solid var(--primary);
    background: #ffffff;
    padding: 0.65rem 0.85rem;
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--text-main);
  }

  .cdk-drag-placeholder {
    opacity: 0.25;
    background: #cbd5e1;
    border: 2px dashed #94a3b8;
    border-radius: var(--radius-sm);
  }

  .cdk-drag-animating {
    transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);
  }

  .zone-drop.cdk-drop-list-dragging .carte-invite:not(.cdk-drag-placeholder) {
    transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);
  }
`]
})
export class TablePlanComponent implements OnInit {
  tables = signal<TableAvecInvites[]>([]);
  tousLesInvites = signal<InviteAdmin[]>([]);
  enCours = signal(false);
  erreur = signal<string | null>(null);

  nouvelleTable = { nom: '', capacite: 8 };

  constructor(
    private tableAdminService: TableAdminService,
    private inviteAdminService: InviteAdminService
  ) {}

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.tableAdminService.lister().subscribe(tables => {
      this.inviteAdminService.lister().subscribe(invites => {
        this.tousLesInvites.set(invites);
        this.tables.set(tables.map(t => ({
          ...t,
          invites: invites.filter(i => i.tableId === t.id)
        })));
      });
    });
  }

  nonAffectes(): InviteAdmin[] {
    return this.tousLesInvites().filter(i => !i.tableId);
  }

  idsListesTables(): string[] {
    return this.tables().map(t => 'table-' + t.id);
  }

  /** Toutes les zones de drop sauf celle-ci-même (permet le drag vers n'importe quelle autre colonne). */
  idsListesConnectees(tableIdActuelle: string): string[] {
    return ['non-affectes', ...this.tables().filter(t => t.id !== tableIdActuelle).map(t => 'table-' + t.id)];
  }

  creerTable(): void {
    if (!this.nouvelleTable.nom || this.nouvelleTable.capacite < 1) return;
    this.enCours.set(true);
    this.tableAdminService.creer(this.nouvelleTable.nom, this.nouvelleTable.capacite).subscribe({
      next: () => {
        this.enCours.set(false);
        this.nouvelleTable = { nom: '', capacite: 8 };
        this.charger();
      },
      error: () => this.enCours.set(false)
    });
  }

  supprimerTable(tableId: string): void {
    // Les invités de cette table repassent automatiquement en "non affectés" côté backend
    // (contrainte ON DELETE SET NULL), on recharge donc simplement après suppression.
    this.tableAdminService.supprimer(tableId).subscribe(() => this.charger());
  }

  onDrop(event: CdkDragDrop<InviteAdmin[]>, tableIdCible: string | null): void {
    this.erreur.set(null);
    const invite = event.previousContainer.data[event.previousIndex];

    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      return;
    }

    // Mise à jour optimiste de l'UI, avec rollback si le serveur refuse
    // (ex: table déjà pleine — la capacité est toujours revalidée côté backend).
    transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);

    this.tableAdminService.affecter(invite.id, tableIdCible).subscribe({
      next: () => {
        invite.tableId = tableIdCible;
      },
      error: (err) => {
        // Rollback : on remet l'invité dans sa colonne d'origine.
        const indexActuel = event.container.data.indexOf(invite);
        transferArrayItem(event.container.data, event.previousContainer.data, indexActuel, event.previousIndex);
        this.erreur.set(err?.error?.message ?? "Impossible de déplacer cet invité (table probablement pleine).");
      }
    });
  }
}
