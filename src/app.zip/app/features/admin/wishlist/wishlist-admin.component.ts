import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { WishlistAdminService } from '../../../core/wishlist-admin.service';
import { WishlistItem, WishlistItemAdmin } from '../../../core/models/admin.models';

@Component({
  selector: 'app-wishlist-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h1>Liste de mariage</h1>
    <p class="sous-titre">Visible par vos invités sur la page publique.</p>

    <form class="carte creation" (ngSubmit)="creer()">
      <input class="champ" name="nom" [(ngModel)]="nouveau.nom" placeholder="Nom du cadeau" required />
      <input class="champ" name="prix" [(ngModel)]="nouveau.prix" placeholder="Prix (optionnel)" type="number" min="0" step="0.01" />
      <input class="champ" name="lien" [(ngModel)]="nouveau.lien" placeholder="Lien (optionnel)" />
      <input class="champ" name="imageUrl" [(ngModel)]="nouveau.imageUrl" placeholder="URL image (optionnel)" />
      <textarea class="champ" name="description" [(ngModel)]="nouveau.description" placeholder="Description (optionnel)"></textarea>
      <button type="submit" class="btn btn-plein" [disabled]="enCours()">Ajouter à la liste</button>
    </form>

    <div class="grille">
      @for (item of items(); track item.id) {
        <div class="carte item" [class.reserve]="!!item.reservePar">
          @if (item.imageUrl) {
            <img [src]="item.imageUrl" alt="" />
          }
          <div class="infos">
            <p class="nom">{{ item.nom }}</p>
            @if (item.prix) {
              <p class="prix">{{ item.prix }} €</p>
            }
            @if (item.description) {
              <p class="description">{{ item.description }}</p>
            }
            @if (item.reservePar) {
              <span class="badge badge-or">Réservé par {{ item.reservePar }}</span>
            } @else {
              <span class="badge badge-succes">Disponible</span>
            }
          </div>
          <button class="btn btn-discret supprimer" (click)="supprimer(item.id)">Supprimer</button>
        </div>
      }
      @if (items().length === 0) {
        <p class="vide">Aucun cadeau ajouté pour l'instant.</p>
      }
    </div>
  `,
 styles: [`
  :host {
    display: block;
    --primary: #4f46e5;
    --primary-hover: #4338ca;
    --surface: #ffffff;
    --background: #f8fafc;
    --border: #e2e8f0;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --gold: #d97706;
    --gold-bg: #fef3c7;
    --gold-border: #fde68a;
    --success: #15803d;
    --success-bg: #dcfce7;
    --danger: #ef4444;
    --danger-bg: #fef2f2;
    --radius: 12px;
    --radius-sm: 8px;
    --shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  }

  h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-main);
    letter-spacing: -0.025em;
    margin: 0;
  }

  .sous-titre {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin: 0.25rem 0 1.5rem;
  }

  /* Carte globale */
  .carte {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
  }

  /* Formulaire de création */
  .creation {
    padding: 1.25rem;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.75rem;
    max-width: 600px;
    margin-bottom: 2rem;
  }

  .creation .champ {
    padding: 0.625rem 0.875rem;
    font-size: 0.875rem;
    color: var(--text-main);
    background-color: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
    box-sizing: border-box;
    width: 100%;
  }

  .creation .champ:focus-visible {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
  }

  .creation textarea.champ {
    grid-column: 1 / -1;
    min-height: 80px;
    resize: vertical;
    font-family: inherit;
  }

  .creation .btn {
    grid-column: 1 / -1;
    justify-self: start;
  }

  /* Boutons */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.625rem 1.25rem;
    font-size: 0.875rem;
    font-weight: 600;
    border-radius: var(--radius-sm);
    border: none;
    cursor: pointer;
    transition: all 0.15s ease;
  }

  .btn-plein {
    background-color: var(--primary);
    color: #ffffff;
  }

  .btn-plein:hover:not(:disabled) {
    background-color: var(--primary-hover);
  }

  .btn-discret {
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
    padding: 0.4rem 0.75rem;
    font-size: 0.8rem;
  }

  .btn-discret:hover {
    background-color: var(--danger-bg);
    color: var(--danger);
    border-color: #fecaca;
  }

  .btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  /* Grille des cadeaux */
  .grille {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 1.25rem;
  }

  /* Carte Item */
  .item {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    position: relative;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .item:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  .item.reserve {
    background-color: #f8fafc;
    border-color: #cbd5e1;
  }

  .item img {
    width: 100%;
    height: 160px;
    object-fit: cover;
    border-bottom: 1px solid var(--border);
  }

  .infos {
    padding: 1rem;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 0.35rem;
  }

  .nom {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-main);
    margin: 0;
    line-height: 1.3;
  }

  .prix {
    font-size: 0.9rem;
    color: var(--gold);
    font-weight: 700;
    margin: 0;
  }

  .description {
    font-size: 0.825rem;
    color: var(--text-muted);
    margin: 0 0 0.5rem;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  /* Badges */
  .badge {
    align-self: flex-start;
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.625rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    margin-top: auto;
  }

  .badge-succes {
    background-color: var(--success-bg);
    color: var(--success);
  }

  .badge-or {
    background-color: var(--gold-bg);
    color: var(--gold);
    border: 1px solid var(--gold-border);
  }

  /* Action de suppression */
  .supprimer {
    margin: 0 1rem 1rem 1rem;
    align-self: flex-end;
  }

  .vide {
    grid-column: 1 / -1;
    color: var(--text-muted);
    font-style: italic;
    text-align: center;
    padding: 3rem 1rem;
  }

  @media (max-width: 640px) {
    .creation {
      grid-template-columns: 1fr;
    }
  }
`]
})
export class WishlistAdminComponent implements OnInit {
  items = signal<WishlistItemAdmin[]>([]);
  enCours = signal(false);

  nouveau: Partial<WishlistItem> = { nom: '', description: '', lien: '', imageUrl: '' };

  constructor(private wishlistAdminService: WishlistAdminService) {}

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.wishlistAdminService.lister().subscribe(items => this.items.set(items));
  }

  creer(): void {
    if (!this.nouveau.nom) return;
    this.enCours.set(true);
    this.wishlistAdminService.creer(this.nouveau).subscribe({
      next: () => {
        this.enCours.set(false);
        this.nouveau = { nom: '', description: '', lien: '', imageUrl: '' };
        this.charger();
      },
      error: () => this.enCours.set(false)
    });
  }

  supprimer(id: string): void {
    this.wishlistAdminService.supprimer(id).subscribe(() => this.charger());
  }
}
