import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InviteAdminService } from '../../../core/invite-admin.service';
import { CreerInviteRequest, InviteAdmin, TypePlace } from '../../../core/models/admin.models';

@Component({
  selector: 'app-invites-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h1>Invités</h1>
    <p class="sous-titre">{{ invites().length }} invité{{ invites().length > 1 ? 's' : '' }} enregistré{{ invites().length > 1 ? 's' : '' }}</p>

    <form class="carte creation" (ngSubmit)="creer()">
      <input class="champ" name="nom" [(ngModel)]="nouveau.nom" placeholder="Nom" required />
      <input class="champ" name="prenom" [(ngModel)]="nouveau.prenom" placeholder="Prénom" required />
      <input class="champ" name="email" [(ngModel)]="nouveau.email" placeholder="Email (optionnel)" type="email" />
      <input class="champ" name="telephone" [(ngModel)]="nouveau.telephone" placeholder="Téléphone (optionnel)" />
      <select class="champ" name="typePlace" [(ngModel)]="nouveau.typePlace" required>
        <option value="SOLO">Solo</option>
        <option value="COUPLE">Couple</option>
      </select>
      <button type="submit" class="btn btn-plein" [disabled]="enCours()">Ajouter</button>
    </form>

    <div class="carte tableau-conteneur">
      <table>
        <thead>
          <tr>
            <th>Nom</th><th>Type</th><th>Statut RSVP</th><th>Conjoint</th><th>Table</th>
          </tr>
        </thead>
        <tbody>
          @for (invite of invites(); track invite.id) {
            <tr>
              <td class="nom-cell">{{ invite.prenom }} {{ invite.nom }}</td>
              <td><span class="badge badge-neutre">{{ invite.typePlace === 'COUPLE' ? 'Couple' : 'Solo' }}</span></td>
            <td>
              <span class="badge" 
                [class.badge-succes]="estConfirme(invite)" 
                [class.badge-declined]="invite.statutRsvp === 'DECLINE'"
                [class.badge-neutre]="!estConfirme(invite) && invite.statutRsvp !== 'DECLINE'">
                {{ libelleStatut(invite.statutRsvp) }}
              </span>
            </td>
              <td>{{ invite.nomConjoint || '—' }}</td>
              <td>{{ invite.tableNom || '—' }}</td>
            </tr>
          }
          @if (invites().length === 0) {
            <tr><td colspan="5" class="vide">Aucun invité pour l'instant.</td></tr>
          }
        </tbody>
      </table>
    </div>
  `,
styles: [`
  :host {
    display: block;
    --primary: #4f46e5;
    --primary-hover: #4338ca;
    --surface: #ffffff;
    --background: #f8fafc;
    --border: #e2e8f0;
    --text-main: #0f172a;
    --text-muted: #64748b;
    --radius: 10px;
    --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  }

  h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-main);
    letter-spacing: -0.025em;
    margin: 0;
  }

  .sous-titre {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin: 0.25rem 0 1.5rem;
  }

  /* Cartes de conteneur */
  .carte {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    transition: box-shadow 0.2s ease;
  }

  /* Formulaire de création */
  .creation {
    padding: 1.25rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 0.75rem;
    align-items: center;
    margin-bottom: 1.75rem;
  }

  .champ {
    width: 100%;
    padding: 0.625rem 0.875rem;
    font-size: 0.875rem;
    color: var(--text-main);
    background-color: var(--surface);
    border: 1px solid var(--border);
    border-radius: calc(var(--radius) - 2px);
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
    box-sizing: border-box;
  }

  .champ:focus-visible {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
  }

  .champ::placeholder {
    color: #94a3b8;
  }

  /* Bouton */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.625rem 1.25rem;
    font-size: 0.875rem;
    font-weight: 600;
    border-radius: calc(var(--radius) - 2px);
    border: none;
    cursor: pointer;
    transition: background-color 0.15s ease, opacity 0.15s ease;
    white-space: nowrap;
  }

  .btn-plein {
    background-color: var(--primary);
    color: #ffffff;
  }

  .btn-plein:hover:not(:disabled) {
    background-color: var(--primary-hover);
  }

  .btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  /* Conteneur et Tableau */
  .tableau-conteneur {
    padding: 0;
    overflow-x: auto;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
    font-size: 0.875rem;
  }

  th {
    padding: 0.875rem 1.25rem;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    background: var(--background);
    border-bottom: 1px solid var(--border);
  }

  td {
    padding: 1rem 1.25rem;
    border-top: 1px solid var(--border);
    color: var(--text-main);
    vertical-align: middle;
  }

  tbody tr {
    transition: background-color 0.15s ease;
  }

  tbody tr:hover {
    background-color: rgba(248, 250, 252, 0.8);
  }

  .nom-cell {
    font-weight: 600;
    color: var(--text-main);
  }

  /* Badges de statut */
  .badge {
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.625rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 500;
  }

  .badge-neutre {
    background-color: #f1f5f9;
    color: #475569;
  }

  .badge-succes {
    background-color: #dcfce7;
    color: #15803d;
  }

  .badge-declined {
    background-color: #fee2e2;
    color: #b91c1c;
  }

  .vide {
    text-align: center;
    color: var(--text-muted);
    font-style: italic;
    padding: 3rem 1.5rem;
  }

  @media (max-width: 640px) {
    .creation {
      grid-template-columns: 1fr;
    }
  }
`]
})
export class InvitesListComponent implements OnInit {
  invites = signal<InviteAdmin[]>([]);
  enCours = signal(false);

  nouveau: CreerInviteRequest = { nom: '', prenom: '', email: '', telephone: '', typePlace: 'SOLO' as TypePlace };

  constructor(private inviteAdminService: InviteAdminService) {}

  ngOnInit(): void {
    this.charger();
  }

  charger(): void {
    this.inviteAdminService.lister().subscribe(invites => this.invites.set(invites));
  }

  creer(): void {
    this.enCours.set(true);
    this.inviteAdminService.creer(this.nouveau).subscribe({
      next: () => {
        this.enCours.set(false);
        this.nouveau = { nom: '', prenom: '', email: '', telephone: '', typePlace: 'SOLO' as TypePlace };
        this.charger();
      },
      error: () => this.enCours.set(false)
    });
  }

  estConfirme(invite: InviteAdmin): boolean {
    return invite.statutRsvp === 'CONFIRME_SOLO' || invite.statutRsvp === 'CONFIRME_COUPLE';
  }

  libelleStatut(statut: string): string {
    switch (statut) {
      case 'CONFIRME_SOLO': return 'Confirmé';
      case 'CONFIRME_COUPLE': return 'Confirmé (couple)';
      case 'DECLINE': return 'Décliné';
      default: return 'En attente';
    }
  }
}
