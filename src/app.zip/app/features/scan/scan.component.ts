import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ScanResultat, ScanService } from '../../core/scan.service';

/**
 * Écran de contrôle d'entrée pour le staff le jour J. Pensé mobile-first
 * (grands boutons, grand texte) : ce sera consulté sur téléphone, à l'entrée.
 *
 * NOTE D'INTÉGRATION : pour un scan caméra réel, brancher une librairie comme
 * `@zxing/ngx-scanner` qui appelle `scanner(contenuQrDetecte)` à chaque lecture
 * réussie. Le champ texte ci-dessous permet de tester le flow sans caméra
 * (ou de saisir manuellement le code si le téléphone d'un invité est cassé).
 */
@Component({
  selector: 'app-scan',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="scene">
      <p class="marque">Mariage App</p>
      <h1>Contrôle d'entrée</h1>

      <form (ngSubmit)="scanner()">
        <input
          class="champ"
          name="contenuQr"
          [(ngModel)]="contenuQr"
          placeholder="Contenu du QR code"
          autocomplete="off"
          required
        />
        <button type="submit" class="btn btn-plein" [disabled]="enCours()">Valider</button>
      </form>

      @if (resultat(); as r) {
        <div class="resultat" [class.epuise]="r.epuise">
          <p class="nom">{{ r.invite }}</p>
          @if (r.nomConjoint) {
            <p class="conjoint">+ {{ r.nomConjoint }}</p>
          }
          <p class="compteur">Entrées : {{ r.nbEntreesScannees }} / {{ r.nbPlaces }}</p>
          @if (r.epuise) {
            <p class="verdict alerte">Billet déjà utilisé en totalité.</p>
          } @else {
            <p class="verdict ok">Entrée validée.</p>
          }
        </div>
      }

      @if (erreur()) {
        <p class="erreur-texte">{{ erreur() }}</p>
      }
    </div>
  `,
  styles: [`
  :host {
    display: block;
    min-height: 100vh;
    background-color: var(--papier, #f8fafc);
    color: var(--encre, #0f172a);
    --succes-bg: #f0fdf4;
    --succes-border: #bbf7d0;
    --succes-texte: #15803d;
    --erreur-bg: #fef2f2;
    --erreur-border: #fecaca;
    --erreur-texte: #b91c1c;
  }

  .scene {
    min-height: 100vh;
    padding: 2.5rem 1.25rem 2rem;
    max-width: 440px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
  }

  .marque {
    font-family: var(--police-affichage, serif);
    font-style: italic;
    font-size: 1.1rem;
    color: var(--or, #d97706);
    margin: 0 0 0.25rem 0;
    letter-spacing: 0.02em;
  }

  h1 {
    font-size: 1.75rem;
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0 0 1.75rem 0;
  }

  /* Formulaire de contrôle */
  form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    margin-bottom: 1.5rem;
  }

  .champ {
    width: 100%;
    font-size: 1.1rem;
    padding: 1rem 1.15rem;
    border: 1px solid var(--trait, #cbd5e1);
    border-radius: 12px;
    background-color: #ffffff;
    color: var(--encre, #0f172a);
    outline: none;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
    box-sizing: border-box;
  }

  .champ:focus {
    border-color: var(--or, #d97706);
    box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
  }

  .btn {
    width: 100%;
    font-size: 1.05rem;
    font-weight: 600;
    padding: 1rem;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    transition: background-color 0.2s ease, transform 0.1s ease, opacity 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .btn-plein {
    background-color: var(--encre, #0f172a);
    color: #ffffff;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  }

  .btn-plein:active:not(:disabled) {
    transform: scale(0.98);
  }

  .btn-plein:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  /* Cartes de Résultat */
  .resultat {
    padding: 1.5rem;
    border-radius: 16px;
    background: var(--succes-bg);
    border: 2px solid var(--succes-border);
    animation: apparition 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    box-shadow: 0 4px 12px rgba(22, 101, 52, 0.08);
  }

  .resultat.epuise {
    background: var(--erreur-bg);
    border-color: var(--erreur-border);
    box-shadow: 0 4px 12px rgba(185, 28, 28, 0.08);
  }

  .nom {
    font-family: var(--police-affichage, serif);
    font-size: 1.65rem;
    font-weight: 700;
    line-height: 1.25;
    margin: 0;
    color: var(--encre, #0f172a);
  }

  .conjoint {
    margin: 0.35rem 0 0;
    font-size: 1.05rem;
    font-weight: 500;
    color: var(--encre-douce, #475569);
  }

  .compteur {
    display: inline-block;
    margin: 1rem 0 0.75rem;
    padding: 0.35rem 0.75rem;
    font-size: 0.85rem;
    font-weight: 600;
    border-radius: 20px;
    background-color: rgba(255, 255, 255, 0.75);
    color: var(--encre, #0f172a);
    border: 1px solid rgba(0, 0, 0, 0.05);
  }

  .verdict {
    font-size: 1.1rem;
    font-weight: 700;
    margin: 0.5rem 0 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .verdict.ok {
    color: var(--succes-texte);
  }

  .verdict.ok::before {
    content: '✓';
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    background: var(--succes-texte);
    color: #ffffff;
    border-radius: 50%;
    font-size: 0.8rem;
  }

  .verdict.alerte {
    color: var(--erreur-texte);
  }

  .verdict.alerte::before {
    content: '✕';
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    background: var(--erreur-texte);
    color: #ffffff;
    border-radius: 50%;
    font-size: 0.8rem;
  }

  /* Message d'erreur technique/scan */
  .erreur-texte {
    padding: 1.15rem;
    border-radius: 12px;
    background-color: var(--erreur-bg);
    border: 1px solid var(--erreur-border);
    color: var(--erreur-texte);
    font-weight: 600;
    font-size: 0.95rem;
    margin: 0;
    animation: apparition 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  }

  @keyframes apparition {
    from {
      opacity: 0;
      transform: translateY(6px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
`]
})
export class ScanComponent {
  contenuQr = '';
  enCours = signal(false);
  resultat = signal<ScanResultat | null>(null);
  erreur = signal<string | null>(null);

  constructor(private scanService: ScanService) {}

  scanner(): void {
    this.erreur.set(null);
    this.enCours.set(true);

    this.scanService.scanner(this.contenuQr).subscribe({
      next: res => {
        this.enCours.set(false);
        this.resultat.set(res);
        this.contenuQr = '';
      },
      error: err => {
        this.enCours.set(false);
        this.resultat.set(null);
        this.erreur.set(err?.error?.message ?? 'QR code invalide ou billet déjà utilisé.');
      }
    });
  }
}
