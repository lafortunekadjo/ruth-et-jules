import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MariagePublic, MariagePublicService } from '../../core/mariage-public.service';

type EtatEnveloppe = 'fermee' | 'ouverture' | 'ouverte';

@Component({
  selector: 'app-save-the-date',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    @if (mariage(); as m) {
      <div
        class="scene"
        [style.--couleur-primaire]="m.couleurPrimaire || '#a88b4a'"
        [style.--couleur-secondaire]="m.couleurSecondaire || '#c48a7b'"
        [style.--couleur-tertiaire]="m.couleurTertiaire || m.couleurPrimaire || '#cdb37c'"
        [style.--couleur-fond]="m.couleurFond || '#fffdfa'"
        [style.--couleur-texte]="m.couleurTexte || m.couleurSecondaire || '#2a2724'"
        [style.font-family]="m.police ? m.police + ', var(--police-affichage)' : 'var(--police-affichage)'"
      >

        <!-- ============ Enveloppe (écran d'accueil) ============ -->
        @if (etat() !== 'ouverte') {
          <section class="ecran-enveloppe" [class.ouverture]="etat() === 'ouverture'">
            <p class="eyebrow">Save the date · {{ annee(m) }}</p>
            <p class="monogramme-titre">{{ monogramme(m) }}</p>

            <button type="button" class="enveloppe" (click)="ouvrir()" [disabled]="etat() === 'ouverture'">
              <span class="rabat"></span>
              <span class="corps">
                <span class="cachet">{{ monogramme(m) }}</span>
              </span>
            </button>

            <p class="indice">touchez le cachet pour ouvrir votre invitation</p>
          </section>
        }

        <!-- ============ Contenu principal (après ouverture) ============ -->
        @if (etat() === 'ouverte') {
          <section class="hero" [class.avec-image]="!!m.imageCouvertureUrl"
                    [style.background-image]="m.imageCouvertureUrl ? 'linear-gradient(180deg, rgba(0,0,0,0.15), rgba(0,0,0,0.35)), url(' + m.imageCouvertureUrl + ')' : null">

            <p class="monogramme-petit">{{ monogramme(m) }}</p>
            <p class="annonce">Save the date</p>

            <h1 class="noms">{{ m.nomsCouple }}</h1>

            <div class="separateur-hero" aria-hidden="true">
              <span></span><span class="losange"></span><span></span>
            </div>

            <p class="accueil">{{ m.messageAccueil || 'Vous êtes convié·e' }}</p>

            <div class="details">
              @if (m.dateMariage) {
                <p class="date">{{ formaterDate(m.dateMariage) }}</p>
              }
              @if (m.lieu) {
                <p class="lieu">{{ m.lieu }}</p>
              }
            </div>
          </section>

          @if (joursRestants(); as jours) {
            @if (jours > 0) {
              <section class="compte-a-rebours">
                <span class="chiffre">{{ jours }}</span>
                <span class="mot">jour{{ jours > 1 ? 's' : '' }} avant le grand jour</span>
              </section>
            } @else if (jours === 0) {
              <section class="compte-a-rebours">
                <span class="mot mot-seul">C'est aujourd'hui !</span>
              </section>
            }
          }

          @if (m.heureCeremonie || m.tenueSouhaitee) {
            <section class="programme">
              <div class="separateur" aria-hidden="true"><span class="losange"></span></div>
              <h2>Le programme</h2>

              @if (m.heureCeremonie) {
                <div class="ligne-programme">
                  <span class="heure">{{ m.heureCeremonie }}</span>
                  <span class="texte">
                    Cérémonie
                    @if (m.lieu) { <span class="sous-texte">{{ m.lieu }}</span> }
                  </span>
                </div>
              }

              @if (m.tenueSouhaitee) {
                <p class="dress-code"><strong>Tenue souhaitée</strong> — {{ m.tenueSouhaitee }}</p>
              }
            </section>
          }

          <section class="appel">
            <div class="separateur" aria-hidden="true"><span class="losange"></span></div>
            <p class="invitation-texte">Nous serions heureux de vous compter parmi nous.</p>
            <a [routerLink]="['/m', m.slug, 'rsvp']" class="bouton-rsvp">Confirmer ma présence</a>

            <div class="liens-secondaires">
              @if (m.wishlistActive) {
                <a [routerLink]="['/m', m.slug, 'wishlist']">Liste de mariage</a>
              }
              @if (m.galeriePhotoActive) {
                <a [routerLink]="['/m', m.slug, 'photos']">Galerie photo</a>
              }
              <a [routerLink]="['/m', m.slug, 'livre-or']">Livre d'or</a>
            </div>
          </section>
        }
      </div>
    } @else if (introuvable()) {
      <div class="scene introuvable">
        <p>Ce mariage n'existe pas ou n'est plus accessible.</p>
      </div>
    }
  `,
  styles: [`
    .scene {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      background: var(--couleur-fond, #fffdfa);
      color: var(--couleur-texte, #2a2724);
    }

    .introuvable {
      justify-content: center;
      font-family: var(--police-texte);
      color: var(--encre-douce);
    }

    /* ---------- Écran enveloppe ---------- */
    .ecran-enveloppe {
      min-height: 100vh;
      width: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 1.25rem;
      padding: 2rem;
      text-align: center;
      background: radial-gradient(circle at 50% 30%, color-mix(in srgb, var(--couleur-primaire) 14%, var(--couleur-fond)), var(--couleur-fond) 70%);
      transition: opacity 400ms ease;
    }
    .ecran-enveloppe.ouverture { opacity: 0; pointer-events: none; }

    .eyebrow {
      font-family: var(--police-texte);
      font-size: 0.8rem;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      color: var(--couleur-secondaire);
      opacity: 0.8;
    }

    .monogramme-titre {
      font-family: var(--police-affichage);
      font-style: italic;
      font-size: 2.75rem;
      color: var(--couleur-primaire);
      margin-bottom: 1rem;
    }

    .enveloppe {
      position: relative;
      width: min(320px, 80vw);
      aspect-ratio: 16 / 10;
      background: none;
      border: none;
      padding: 0;
      cursor: pointer;
      font: inherit;
    }
    .corps {
      position: absolute;
      inset: 0;
      background: color-mix(in srgb, var(--couleur-primaire) 12%, #fff);
      border: 1px solid color-mix(in srgb, var(--couleur-primaire) 45%, transparent);
      border-radius: 4px;
      display: flex;
      align-items: flex-end;
      justify-content: center;
      padding-bottom: 14%;
      box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    }
    .rabat {
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 0;
      border-left: calc(min(320px, 80vw) / 2) solid transparent;
      border-right: calc(min(320px, 80vw) / 2) solid transparent;
      border-top: calc(min(320px, 80vw) * 0.34) solid color-mix(in srgb, var(--couleur-primaire) 22%, #fff);
      transform-origin: top center;
      transition: transform 550ms cubic-bezier(.4,0,.2,1);
      z-index: 2;
    }
    .enveloppe:hover .rabat { filter: brightness(1.03); }
    .ouverture .rabat { transform: rotateX(180deg); }

    .cachet {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: var(--couleur-primaire);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: var(--police-affichage);
      font-style: italic;
      font-size: 1.1rem;
      box-shadow: 0 4px 12px color-mix(in srgb, var(--couleur-primaire) 50%, transparent);
      z-index: 3;
      transition: transform 400ms ease, opacity 400ms ease;
    }
    .ouverture .cachet { transform: scale(0); opacity: 0; }

    .indice {
      font-family: var(--police-texte);
      font-size: 0.85rem;
      color: var(--couleur-texte);
      opacity: 0.55;
    }

    /* ---------- Hero principal ---------- */
    .hero {
      width: 100%;
      min-height: 90vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 3rem 1.5rem;
      background: radial-gradient(circle at 30% 20%, color-mix(in srgb, var(--couleur-primaire) 18%, var(--couleur-fond)), var(--couleur-fond) 65%);
      animation: apparition 700ms ease both;
    }
    .hero.avec-image {
      background-size: cover;
      background-position: center;
      color: #fff;
    }
    @keyframes apparition {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .monogramme-petit {
      font-family: var(--police-affichage);
      font-style: italic;
      font-size: 1.4rem;
      color: var(--couleur-primaire);
      margin-bottom: 0.75rem;
    }
    .hero.avec-image .monogramme-petit { color: #fff; }

    .annonce {
      font-family: var(--police-texte);
      font-size: 0.8rem;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      opacity: 0.75;
      margin-bottom: 0.5rem;
    }

    .noms {
      font-size: clamp(2.5rem, 7vw, 5rem);
      font-style: italic;
      font-weight: 500;
      color: var(--couleur-primaire);
      max-width: 16ch;
    }
    .hero.avec-image .noms { color: #fff; }

    .separateur-hero {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      width: 140px;
      margin: 1.5rem 0 1.15rem;
      color: var(--couleur-primaire);
    }
    .hero.avec-image .separateur-hero { color: #fff; }
    .separateur-hero span:not(.losange) { flex: 1; height: 1px; background: currentColor; opacity: 0.55; }
    .separateur-hero .losange { width: 6px; height: 6px; background: currentColor; transform: rotate(45deg); flex: none; }

    .accueil {
      font-family: var(--police-affichage);
      font-style: italic;
      font-size: 1.05rem;
      opacity: 0.85;
      margin-bottom: 1.5rem;
    }

    .details { font-family: var(--police-texte); }
    .date { font-size: 1.1rem; text-transform: capitalize; margin-bottom: 0.25rem; }
    .lieu { font-size: 0.95rem; opacity: 0.8; }

    /* ---------- Compte à rebours ---------- */
    .compte-a-rebours {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2.5rem 1.5rem;
      font-family: var(--police-texte);
    }
    .chiffre {
      font-family: var(--police-affichage);
      font-size: 3.25rem;
      color: var(--couleur-primaire);
      line-height: 1;
    }
    .mot { font-size: 0.9rem; opacity: 0.7; margin-top: 0.4rem; }
    .mot-seul { font-family: var(--police-affichage); font-size: 1.4rem; font-style: italic; opacity: 1; }

    /* ---------- Séparateur générique ---------- */
    .separateur { display: flex; justify-content: center; color: var(--couleur-secondaire); opacity: 0.6; margin-bottom: 1.25rem; }
    .separateur .losange { width: 6px; height: 6px; background: currentColor; transform: rotate(45deg); }

    /* ---------- Programme ---------- */
    .programme {
      width: 100%;
      max-width: 480px;
      padding: 2rem 1.5rem 1rem;
      text-align: center;
      font-family: var(--police-texte);
    }
    .programme h2 {
      font-family: var(--police-affichage);
      font-size: 1.5rem;
      margin-bottom: 1.25rem;
      color: var(--couleur-texte);
    }
    .ligne-programme {
      display: flex;
      align-items: baseline;
      justify-content: center;
      gap: 1rem;
      margin-bottom: 1rem;
    }
    .ligne-programme .heure {
      font-family: var(--police-affichage);
      font-size: 1.3rem;
      color: var(--couleur-primaire);
    }
    .ligne-programme .texte { text-align: left; font-size: 0.95rem; }
    .ligne-programme .sous-texte { display: block; font-size: 0.8rem; opacity: 0.65; }
    .dress-code { font-size: 0.9rem; opacity: 0.85; margin-top: 0.5rem; }

    /* ---------- Appel à l'action ---------- */
    .appel {
      padding: 1rem 1.5rem 4rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1.25rem;
      text-align: center;
    }
    .invitation-texte { font-family: var(--police-texte); max-width: 40ch; opacity: 0.8; }

    .bouton-rsvp {
      font-family: var(--police-texte);
      font-weight: 600;
      font-size: 1rem;
      text-decoration: none;
      color: #fff;
      background: var(--couleur-primaire);
      padding: 0.95rem 2.5rem;
      border-radius: 999px;
      transition: transform 150ms ease, box-shadow 150ms ease;
      box-shadow: 0 6px 20px color-mix(in srgb, var(--couleur-primaire) 35%, transparent);
    }
    .bouton-rsvp:hover { transform: translateY(-2px); }

    .liens-secondaires {
      display: flex;
      gap: 1.5rem;
      flex-wrap: wrap;
      justify-content: center;
      font-family: var(--police-texte);
      font-size: 0.9rem;
    }
    .liens-secondaires a {
      color: var(--couleur-texte);
      opacity: 0.7;
      text-decoration: none;
      border-bottom: 1px solid currentColor;
      padding-bottom: 2px;
    }
    .liens-secondaires a:hover { opacity: 1; color: var(--couleur-primaire); }

    @media (max-width: 480px) {
      .noms { font-size: clamp(2.1rem, 10vw, 3rem); }
    }
  `]
})
export class SaveTheDateComponent implements OnInit {
  mariage = signal<MariagePublic | null>(null);
  introuvable = signal(false);
  etat = signal<EtatEnveloppe>('fermee');

  constructor(private route: ActivatedRoute, private mariagePublicService: MariagePublicService) {}

  ngOnInit(): void {
    const slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.mariagePublicService.consulter(slug).subscribe({
      next: m => this.mariage.set(m),
      error: () => this.introuvable.set(true)
    });
  }

  ouvrir(): void {
    if (this.etat() !== 'fermee') return;
    this.etat.set('ouverture');
    setTimeout(() => this.etat.set('ouverte'), 550);
  }

  annee(m: MariagePublic): string {
    return m.dateMariage ? new Date(m.dateMariage).getFullYear().toString() : '';
  }

  /** Dérive un monogramme ("D & S") à partir de "Danielle & Steve" ou "Julie et Marc". */
  monogramme(m: MariagePublic): string {
    const parties = m.nomsCouple.split(/\s+(?:&|et)\s+/i);
    if (parties.length === 2) {
      const initiale = (s: string) => s.trim().charAt(0).toUpperCase();
      return `${initiale(parties[0])} & ${initiale(parties[1])}`;
    }
    return m.nomsCouple.trim().charAt(0).toUpperCase();
  }

  joursRestants(): number | null {
    const m = this.mariage();
    if (!m?.dateMariage) return null;
    const cible = new Date(m.dateMariage).getTime();
    const maintenant = new Date().setHours(0, 0, 0, 0);
    return Math.ceil((cible - maintenant) / (1000 * 60 * 60 * 24));
  }

  formaterDate(dateIso: string): string {
    return new Date(dateIso).toLocaleDateString('fr-FR', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
  }
}
