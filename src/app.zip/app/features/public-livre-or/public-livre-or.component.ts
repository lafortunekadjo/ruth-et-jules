import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MariagePublic, MariagePublicService } from '../../core/mariage-public.service';
import { LivreOrPublicService } from '../../core/livre-or-public.service';
import { MessageLivreOr } from '../../core/models/admin.models';

@Component({
  selector: 'app-public-livre-or',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div
      class="scene"
      [style.--couleur-primaire]="couleur('couleurPrimaire', '#a88b4a')"
      [style.--couleur-fond]="couleur('couleurFond', '#fffdfa')"
      [style.--couleur-texte]="couleur('couleurTexte', '#2a2724')"
      [style.font-family]="mariage?.police ? mariage!.police + ', var(--police-affichage)' : 'var(--police-affichage)'"
    >
      <a class="retour" [routerLink]="['/m', slug]">← Retour</a>

      <p class="monogramme" *ngIf="mariage">{{ mariage.nomsCouple }}</p>
      <h1>Livre d'or</h1>
      <p class="intro">Laissez un mot doux aux mariés — il sera visible ici après validation.</p>

      <form class="formulaire" (ngSubmit)="deposer()">
        <input class="champ" name="auteur" [(ngModel)]="auteur" placeholder="Votre nom" required maxlength="150" />
        <textarea class="champ" name="message" [(ngModel)]="message" placeholder="Votre message..." required maxlength="2000" rows="4"></textarea>
        <button class="bouton" type="submit" [disabled]="envoi || !auteur || !message">Envoyer</button>
        @if (envoye) {
          <p class="confirmation">Merci ! Votre message sera visible dès qu'il aura été validé par les mariés.</p>
        }
      </form>

      <div class="separateur"><span class="losange"></span></div>

      <div class="messages">
        @for (m of messages(); track m.id) {
          <div class="carte">
            <p class="texte">{{ m.message }}</p>
            <p class="auteur">— {{ m.auteur }}</p>
          </div>
        }
        @if (messages().length === 0) {
          <p class="vide">Soyez le premier à laisser un mot !</p>
        }
      </div>
    </div>
  `,
  styles: [`
    .scene { min-height: 100vh; background: var(--couleur-fond); color: var(--couleur-texte); padding: 2rem 1.5rem 4rem; }
    .retour { font-family: var(--police-texte); font-size: 0.85rem; color: inherit; opacity: 0.6; text-decoration: none; }
    .monogramme { font-family: var(--police-affichage); font-style: italic; color: var(--couleur-primaire); text-align: center; margin: 1.5rem 0 0.25rem; }
    h1 { font-family: var(--police-affichage); text-align: center; font-size: 2rem; font-weight: 500; margin-bottom: 0.5rem; }
    .intro { text-align: center; max-width: 440px; margin: 0 auto 2rem; font-family: var(--police-texte); opacity: 0.75; }

    .formulaire { max-width: 460px; margin: 0 auto; display: flex; flex-direction: column; gap: 0.75rem; }
    .champ { padding: 0.65rem 0.85rem; border: 1px solid #ddd; border-radius: 6px; font-family: var(--police-texte); font-size: 0.95rem; }
    .bouton {
      font-family: var(--police-texte); font-weight: 600; color: #fff; background: var(--couleur-primaire);
      border: none; border-radius: 999px; padding: 0.7rem 1.4rem; cursor: pointer;
    }
    .bouton:disabled { opacity: 0.5; cursor: not-allowed; }
    .confirmation { font-size: 0.85rem; color: var(--couleur-primaire); text-align: center; }

    .separateur { display: flex; justify-content: center; color: var(--couleur-primaire); opacity: 0.5; margin: 2.5rem 0; }
    .separateur .losange { width: 6px; height: 6px; background: currentColor; transform: rotate(45deg); }

    .messages { max-width: 620px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1.25rem; }
    .vide { grid-column: 1 / -1; text-align: center; opacity: 0.6; font-style: italic; }
    .carte { background: #fff; border: 1px solid color-mix(in srgb, var(--couleur-primaire) 18%, transparent); border-radius: 8px; padding: 1.1rem; }
    .texte { font-family: var(--police-texte); line-height: 1.5; margin: 0 0 0.6rem; }
    .auteur { font-family: var(--police-affichage); font-style: italic; margin: 0; color: var(--couleur-primaire); }
  `]
})
export class PublicLivreOrComponent implements OnInit {
  slug = '';
  mariage: MariagePublic | null = null;
  messages = signal<MessageLivreOr[]>([]);

  auteur = '';
  message = '';
  envoi = false;
  envoye = false;

  constructor(
    private route: ActivatedRoute,
    private mariagePublicService: MariagePublicService,
    private livreOrPublicService: LivreOrPublicService
  ) {}

  ngOnInit(): void {
    this.slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.mariagePublicService.consulter(this.slug).subscribe(m => this.mariage = m);
    this.charger();
  }

  charger(): void {
    this.livreOrPublicService.lister(this.slug).subscribe(m => this.messages.set(m));
  }

  couleur(cle: keyof MariagePublic, defaut: string): string {
    const valeur = this.mariage?.[cle] as string | null | undefined;
    return valeur || defaut;
  }

  deposer(): void {
    this.envoi = true;
    this.livreOrPublicService.deposer(this.slug, this.auteur, this.message).subscribe({
      next: () => {
        this.envoi = false;
        this.envoye = true;
        this.auteur = '';
        this.message = '';
      },
      error: () => this.envoi = false
    });
  }
}
