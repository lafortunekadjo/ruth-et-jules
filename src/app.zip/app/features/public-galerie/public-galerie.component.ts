import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MariagePublic, MariagePublicService } from '../../core/mariage-public.service';
import { PhotosPublicService } from '../../core/photos-public.service';
import { PhotoItem } from '../../core/models/admin.models';

@Component({
  selector: 'app-public-galerie',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div
      class="scene"
      [style.--couleur-primaire]="couleur('couleurPrimaire', '#a88b4a')"
      [style.--couleur-fond]="couleur('couleurFond', '#fffdfa')"
      [style.--couleur-texte]="couleur('couleurTexte', '#2a2724')"
      [style.font-family]="mariage?.police ? mariage!.police + ', var(--police-affichage)' : 'var(--police-affichage)'"
    >
      <a class="retour" [routerLink]="['/m', slug]">← Retour</a>

      <p class="monogramme" *ngIf="mariage">{{ mariage.nomsCouple }}</p>
      <h1>Galerie photo</h1>
      <p class="intro">Les souvenirs partagés par les invités, une fois validés par les mariés.</p>

      <div class="grille">
        @for (photo of photos(); track photo.id) {
          <div class="carte">
            <img [src]="photo.url" alt="" />
          </div>
        }
      </div>

      @if (photos().length === 0) {
        <p class="vide">Aucune photo pour l'instant — revenez après le grand jour !</p>
      }
    </div>
  `,
  styles: [`
    .scene { min-height: 100vh; background: var(--couleur-fond); color: var(--couleur-texte); padding: 2rem 1.5rem 4rem; }
    .retour { font-family: var(--police-texte); font-size: 0.85rem; color: inherit; opacity: 0.6; text-decoration: none; }
    .monogramme { font-family: var(--police-affichage); font-style: italic; color: var(--couleur-primaire); text-align: center; margin: 1.5rem 0 0.25rem; }
    h1 { font-family: var(--police-affichage); text-align: center; font-size: 2rem; font-weight: 500; margin-bottom: 0.5rem; }
    .intro { text-align: center; max-width: 460px; margin: 0 auto 2.5rem; font-family: var(--police-texte); opacity: 0.75; }
    .vide { text-align: center; opacity: 0.6; font-style: italic; }

    .grille {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 0.85rem;
      max-width: 960px;
      margin: 0 auto;
    }
    .carte { border-radius: 6px; overflow: hidden; aspect-ratio: 1; }
    .carte img { width: 100%; height: 100%; object-fit: cover; display: block; }
  `]
})
export class PublicGalerieComponent implements OnInit {
  slug = '';
  mariage: MariagePublic | null = null;
  photos = signal<PhotoItem[]>([]);

  constructor(
    private route: ActivatedRoute,
    private mariagePublicService: MariagePublicService,
    private photosPublicService: PhotosPublicService
  ) {}

  ngOnInit(): void {
    this.slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.mariagePublicService.consulter(this.slug).subscribe(m => this.mariage = m);
    this.photosPublicService.lister(this.slug).subscribe(p => this.photos.set(p));
  }

  couleur(cle: keyof MariagePublic, defaut: string): string {
    const valeur = this.mariage?.[cle] as string | null | undefined;
    return valeur || defaut;
  }
}
