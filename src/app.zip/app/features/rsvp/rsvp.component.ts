import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RsvpService, IdentificationResponse } from '../../core/rsvp.service';
import { MariagePublic, MariagePublicService } from '../../core/mariage-public.service';

type Etape = 'IDENTIFICATION' | 'PRESENCE' | 'CONJOINT' | 'RESULTAT';

@Component({
  selector: 'app-rsvp',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div
      class="scene"
      [style.--couleur-primaire]="couleur('couleurPrimaire', '#a88b4a')"
      [style.--couleur-secondaire]="couleur('couleurSecondaire', '#c48a7b')"
      [style.--couleur-fond]="couleur('couleurFond', '#fffdfa')"
      [style.--couleur-texte]="couleur('couleurTexte', '#2a2724')"
      [style.font-family]="mariage?.police ? mariage!.police + ', var(--police-affichage)' : 'var(--police-affichage)'"
    >
      <p class="monogramme" *ngIf="mariage">{{ mariage.nomsCouple }}</p>

      <div class="carte">

        <!-- Étape 1 : identification -->
        <form *ngIf="etape === 'IDENTIFICATION'" (ngSubmit)="identifier()">
          <h1>Confirmez votre présence</h1>
          <p class="intro">Merci de vous identifier avec les informations figurant sur votre invitation.</p>

          <label>Prénom</label>
          <input class="champ" name="prenom" [(ngModel)]="prenom" required maxlength="100" autocomplete="given-name" />

          <label>Nom</label>
          <input class="champ" name="nom" [(ngModel)]="nom" required maxlength="100" autocomplete="family-name" />

          <p class="erreur" *ngIf="erreur">{{ erreur }}</p>
          <button type="submit" class="bouton" [disabled]="chargement">Continuer</button>
        </form>

        <!-- Étape 2 : présence -->
        <div *ngIf="etape === 'PRESENCE'">
          <h1>Bonjour {{ identification?.prenom }}</h1>
          <p class="intro">Serez-vous des nôtres pour ce grand jour ?</p>

          <div class="choix">
            <button class="bouton" (click)="repondrePresence(true)" [disabled]="chargement">Je serai présent·e</button>
            <button class="bouton bouton-discret" (click)="repondrePresence(false)" [disabled]="chargement">Je ne pourrai pas venir</button>
          </div>
          <p class="erreur" *ngIf="erreur">{{ erreur }}</p>
        </div>

        <!-- Étape 3 : conjoint (uniquement si typePlace === COUPLE) -->
        <div *ngIf="etape === 'CONJOINT'">
          <h1>Votre invitation est pour deux</h1>
          <p class="intro">Votre conjoint·e sera-t-il/elle présent·e ?</p>

          <div class="choix" *ngIf="!conjointPresentChoisi">
            <button class="bouton" (click)="choisirConjoint(true)" [disabled]="chargement">Oui, nous viendrons ensemble</button>
            <button class="bouton bouton-discret" (click)="choisirConjoint(false)" [disabled]="chargement">Non, je viens seul·e</button>
          </div>

          <div *ngIf="conjointPresentChoisi">
            <label>Nom du conjoint / de la conjointe</label>
            <input class="champ" name="nomConjoint" [(ngModel)]="nomConjoint" required maxlength="150" />
            <button class="bouton" (click)="validerConjoint()" [disabled]="chargement || !nomConjoint">Valider</button>
          </div>

          <p class="erreur" *ngIf="erreur">{{ erreur }}</p>
        </div>

        <!-- Étape 4 : résultat -->
        <div *ngIf="etape === 'RESULTAT'" class="resultat">

          <ng-container *ngIf="resultatStatut === 'DECLINE'; else confirme">
            <h1>Merci pour votre réponse</h1>
            <p class="intro">Vous nous manquerez, mais nous vous remercions d'avoir pris le temps de répondre.</p>
          </ng-container>

          <ng-template #confirme>
            <h1>Votre présence est confirmée</h1>
            <p class="intro">Voici votre billet — présentez-le à l'entrée le jour J.</p>

            <div class="billet" *ngIf="billetUrl">
              <div class="billet-entete">
                <span>{{ mariage?.nomsCouple }}</span>
              </div>
              <div class="billet-corps">
                <div class="billet-infos">
                  <p class="billet-label">Billet de mariage</p>
                  <p class="billet-nom">{{ identification?.prenom }} {{ identification?.nom }}</p>
                  <p class="billet-conjoint" *ngIf="nomConjointConfirme">+ {{ nomConjointConfirme }}</p>

                  <div class="billet-separateur"></div>

                  <div class="billet-date" *ngIf="mariage?.dateMariage">
                    <span class="jour">{{ formaterJour(mariage!.dateMariage!) }}</span>
                    <span class="reste">{{ formaterMoisAnnee(mariage!.dateMariage!) }}</span>
                    <span class="heure" *ngIf="mariage?.heureCeremonie">{{ mariage!.heureCeremonie }}</span>
                  </div>

                  <p class="billet-lieu" *ngIf="mariage?.lieu">{{ mariage!.lieu }}</p>
                  <p class="billet-tenue" *ngIf="mariage?.tenueSouhaitee">Tenue : {{ mariage!.tenueSouhaitee }}</p>
                </div>

                <div class="billet-qr">
                  <img [src]="billetUrl" alt="QR code du billet" />
                  <span>accès</span>
                </div>
              </div>
            </div>
          </ng-template>
        </div>

      </div>
    </div>
  `,
  styles: [`
    .scene {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem 1.25rem;
      background: var(--couleur-fond, #fffdfa);
      color: var(--couleur-texte, #2a2724);
    }

    .monogramme {
      font-family: var(--police-affichage);
      font-style: italic;
      font-size: 1.3rem;
      color: var(--couleur-primaire);
      margin-bottom: 1.5rem;
      text-align: center;
    }

    .carte {
      width: 100%;
      max-width: 440px;
      background: #fff;
      border: 1px solid color-mix(in srgb, var(--couleur-primaire) 25%, transparent);
      border-radius: 10px;
      padding: 2.25rem 2rem;
      box-shadow: 0 10px 40px rgba(0,0,0,0.06);
      text-align: center;
    }

    h1 {
      font-family: var(--police-affichage);
      font-size: 1.6rem;
      font-weight: 500;
      margin-bottom: 0.5rem;
    }

    .intro {
      font-family: var(--police-texte);
      font-size: 0.95rem;
      opacity: 0.75;
      margin-bottom: 1.5rem;
    }

    label {
      display: block;
      text-align: left;
      font-family: var(--police-texte);
      font-size: 0.8rem;
      font-weight: 600;
      margin: 1rem 0 0.35rem;
      opacity: 0.8;
    }

    .champ {
      width: 100%;
      font-family: var(--police-texte);
      font-size: 0.95rem;
      padding: 0.7rem 0.9rem;
      border: 1px solid #ddd;
      border-radius: 6px;
    }
    .champ:focus { outline: none; border-color: var(--couleur-primaire); }

    .choix { display: flex; flex-direction: column; gap: 0.75rem; margin-top: 0.5rem; }

    .bouton {
      font-family: var(--police-texte);
      font-weight: 600;
      font-size: 0.95rem;
      color: #fff;
      background: var(--couleur-primaire);
      border: none;
      border-radius: 999px;
      padding: 0.85rem 1.5rem;
      cursor: pointer;
      margin-top: 1.5rem;
      width: 100%;
      transition: transform 120ms ease, opacity 120ms ease;
    }
    .bouton:disabled { opacity: 0.5; cursor: not-allowed; }
    .bouton:active:not(:disabled) { transform: scale(0.98); }
    .choix .bouton { margin-top: 0; }

    .bouton-discret {
      background: transparent;
      color: var(--couleur-texte);
      border: 1px solid #ddd;
    }

    .erreur {
      color: #b3402f;
      font-size: 0.85rem;
      margin-top: 1rem;
      font-family: var(--police-texte);
    }

    /* ---------- Billet ---------- */
    .resultat h1 { margin-bottom: 0.4rem; }

    .billet {
      margin-top: 1.75rem;
      border-radius: 14px;
      overflow: hidden;
      background: color-mix(in srgb, var(--couleur-texte) 92%, black);
      padding: 0.85rem;
      text-align: left;
    }
    .billet-entete {
      text-align: center;
      font-family: var(--police-affichage);
      font-style: italic;
      color: #fff;
      font-size: 1.05rem;
      padding: 0.6rem 0 1rem;
    }
    .billet-corps {
      background: #fdfbf7;
      border-radius: 8px;
      display: flex;
      position: relative;
    }
    .billet-corps::after {
      content: '';
      position: absolute;
      top: 0; bottom: 0;
      right: 92px;
      border-left: 1.5px dashed #ccc;
    }
    .billet-infos { flex: 1; padding: 1rem 1.1rem; font-family: var(--police-texte); }
    .billet-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.08em; opacity: 0.55; margin-bottom: 0.3rem; }
    .billet-nom { font-family: var(--police-affichage); font-size: 1.15rem; margin-bottom: 0.1rem; }
    .billet-conjoint { font-size: 0.85rem; opacity: 0.7; margin-bottom: 0.4rem; }
    .billet-separateur { border-top: 1px dashed #ddd; margin: 0.6rem 0; }
    .billet-date { display: flex; align-items: baseline; gap: 0.6rem; margin-bottom: 0.3rem; }
    .billet-date .jour { font-family: var(--police-affichage); font-size: 1.4rem; color: var(--couleur-primaire); }
    .billet-date .reste, .billet-date .heure { font-size: 0.8rem; opacity: 0.7; text-transform: capitalize; }
    .billet-lieu, .billet-tenue { font-size: 0.8rem; opacity: 0.65; margin-top: 0.15rem; }

    .billet-qr {
      width: 92px;
      flex: none;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 0.3rem;
      padding: 0.5rem;
    }
    .billet-qr img { width: 100%; height: auto; }
    .billet-qr span {
      font-family: var(--police-texte);
      font-size: 0.62rem;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      opacity: 0.55;
    }
  `]
})
export class RsvpComponent implements OnInit {

  slug = '';
  etape: Etape = 'IDENTIFICATION';
  chargement = false;
  erreur = '';

  mariage: MariagePublic | null = null;

  prenom = '';
  nom = '';

  identification: IdentificationResponse | null = null;
  conjointPresentChoisi = false;
  nomConjoint = '';
  nomConjointConfirme = '';

  resultatStatut = '';
  billetUrl: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private rsvpService: RsvpService,
    private mariagePublicService: MariagePublicService
  ) {}

  ngOnInit(): void {
    this.slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.mariagePublicService.consulter(this.slug).subscribe({
      next: m => this.mariage = m,
      error: () => {} // page reste fonctionnelle même sans les infos de vitrine
    });
  }

  couleur(cle: keyof MariagePublic, defaut: string): string {
    const valeur = this.mariage?.[cle] as string | null | undefined;
    return valeur || defaut;
  }

  identifier(): void {
    this.erreur = '';
    this.chargement = true;

    this.rsvpService.identifier(this.slug, { nom: this.nom, prenom: this.prenom })
      .subscribe({
        next: (res) => {
          this.identification = res;
          this.etape = 'PRESENCE';
          this.chargement = false;
        },
        error: (err) => {
          this.erreur = err?.status === 409
            ? "Plusieurs invitations correspondent à ce nom. Merci de contacter les mariés directement."
            : "Nous ne trouvons pas votre invitation. Vérifiez l'orthographe ou contactez les mariés.";
          this.chargement = false;
        }
      });
  }

  repondrePresence(present: boolean): void {
    if (!this.identification) return;
    this.erreur = '';
    this.chargement = true;

    this.rsvpService.confirmerPresence(this.slug, this.identification.rsvpSessionToken, present)
      .subscribe({
        next: (res) => {
          this.chargement = false;
          if (res.questionConjointRequise) {
            this.etape = 'CONJOINT';
          } else {
            this.afficherResultat(res.statut, res.billetUrl);
          }
        },
        error: () => {
          this.erreur = "Une erreur est survenue, merci de réessayer.";
          this.chargement = false;
        }
      });
  }

  choisirConjoint(present: boolean): void {
    this.conjointPresentChoisi = present;
    if (!present) {
      this.validerConjoint();
    }
  }

  validerConjoint(): void {
    if (!this.identification) return;
    this.erreur = '';
    this.chargement = true;

    this.rsvpService.confirmerConjoint(
      this.slug,
      this.identification.rsvpSessionToken,
      this.conjointPresentChoisi,
      this.conjointPresentChoisi ? this.nomConjoint : undefined
    ).subscribe({
      next: (res) => {
        this.chargement = false;
        if (this.conjointPresentChoisi) {
          this.nomConjointConfirme = this.nomConjoint;
        }
        this.afficherResultat(res.statut, res.billetUrl);
      },
      error: () => {
        this.erreur = "Une erreur est survenue, merci de réessayer.";
        this.chargement = false;
      }
    });
  }

  formaterJour(dateIso: string): string {
    return new Date(dateIso).getDate().toString().padStart(2, '0');
  }

  formaterMoisAnnee(dateIso: string): string {
    return new Date(dateIso).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  }

  private afficherResultat(statut: string, billetUrl: string | null): void {
    this.resultatStatut = statut;
    this.billetUrl = billetUrl;
    this.etape = 'RESULTAT';
  }
}
